export enum TASK_STATUS {
  pending = 'pending',
  on_going = 'on_going',
  completed = 'completed',
}
