export const jwtConstant = {
  secret:
    'Tkn6HuEKowzIykt3nS9ol2opt4fS0NmLS5dsBodBWQKospkf8EKMV2h1K6dMsYbpCEy11X516VSFHZhpEjCJUEDqQgViJ9DUaj5C',
};
